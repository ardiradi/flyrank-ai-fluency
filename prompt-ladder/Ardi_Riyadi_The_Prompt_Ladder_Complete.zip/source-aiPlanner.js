const crypto = require("node:crypto");
const { z } = require("zod");

const nextActionInputSchema = z.object({
  goal: z.string().min(5).max(300),
  constraints: z.array(z.string().min(1).max(120)).max(8).default([]),
  assignmentIds: z.array(z.string().min(2).max(40)).max(12).default([]),
});

const nextActionOutputSchema = z.object({
  summary: z.string(),
  nextActions: z.array(z.object({
    title: z.string(),
    reason: z.string(),
    estimatedMinutes: z.number().int().positive(),
  })).min(1).max(6),
  risks: z.array(z.string()).max(6),
});

function hashInput(input) {
  return crypto.createHash("sha256").update(JSON.stringify(input)).digest("hex");
}

function estimateTokens(text) {
  return Math.ceil(String(text).length / 4);
}

async function callOpenAiCompatible(config, input) {
  const prompt = [
    "Return strict JSON with summary, nextActions, and risks.",
    "Create a practical backend internship action plan.",
    `Goal: ${input.goal}`,
    `Constraints: ${input.constraints.join("; ") || "none"}`,
    `Assignment IDs: ${input.assignmentIds.join(", ") || "none"}`,
  ].join("\n");

  const response = await fetch(`${config.ai.baseUrl.replace(/\/$/, "")}/chat/completions`, {
    method: "POST",
    headers: {
      "content-type": "application/json",
      authorization: `Bearer ${config.ai.apiKey}`,
    },
    body: JSON.stringify({
      model: config.ai.model,
      temperature: 0.2,
      response_format: { type: "json_object" },
      messages: [
        { role: "system", content: "You are a concise technical project planner." },
        { role: "user", content: prompt },
      ],
    }),
  });

  if (!response.ok) {
    const text = await response.text();
    throw new Error(`AI provider failed with ${response.status}: ${text.slice(0, 300)}`);
  }

  const payload = await response.json();
  const content = payload.choices?.[0]?.message?.content || "{}";
  return {
    output: nextActionOutputSchema.parse(JSON.parse(content)),
    usage: payload.usage || {
      prompt_tokens: estimateTokens(prompt),
      completion_tokens: estimateTokens(content),
    },
    provider: config.ai.provider,
    model: config.ai.model,
  };
}

async function callLocalDemo(config, input) {
  const ids = input.assignmentIds.length ? input.assignmentIds : ["BE-01", "BE-02", "BE-05", "BE-06", "BE-08"];
  const nextActions = [
    {
      title: "Lock the smallest runnable API slice",
      reason: "A walking skeleton proves the project is real before extra features appear.",
      estimatedMinutes: 45,
    },
    {
      title: `Map evidence for ${ids.slice(0, 3).join(", ")}`,
      reason: "Submission is faster when README sections already point to the exact code paths.",
      estimatedMinutes: 35,
    },
    {
      title: "Generate a reviewer report as a background job",
      reason: "This demonstrates both reporting and queue concepts with one feature.",
      estimatedMinutes: 60,
    },
  ];

  const output = {
    summary: `Focus on ${ids.length} Backend AI Engineering item(s) that support the capstone goal: ${input.goal}.`,
    nextActions,
    risks: [
      "Do not submit until the GitHub repository is public.",
      "Do not commit secrets or local database files.",
      "Keep the scope below five core features.",
    ],
  };

  return {
    output: nextActionOutputSchema.parse(output),
    usage: {
      prompt_tokens: estimateTokens(JSON.stringify(input)),
      completion_tokens: estimateTokens(JSON.stringify(output)),
    },
    provider: "local-demo",
    model: "deterministic-rules",
  };
}

async function getNextActions({ config, db, input }) {
  const parsed = nextActionInputSchema.parse(input);
  const cacheKey = hashInput(parsed);
  const now = new Date();
  const cached = db.prepare(
    "SELECT output_json FROM ai_cache WHERE cache_key = ? AND expires_at > ?",
  ).get(cacheKey, now.toISOString());

  if (cached) {
    const output = JSON.parse(cached.output_json);
    db.prepare(`
      INSERT INTO ai_cost_logs (provider, model, cache_hit)
      VALUES (?, ?, 1)
    `).run(config.ai.provider || "local-demo", config.ai.model || "cache");
    return { cacheHit: true, output };
  }

  const result = config.ai.apiKey
    ? await callOpenAiCompatible(config, parsed)
    : await callLocalDemo(config, parsed);

  const expiresAt = new Date(now.getTime() + 10 * 60 * 1000).toISOString();
  db.prepare(`
    INSERT INTO ai_cache (cache_key, input_json, output_json, expires_at)
    VALUES (?, ?, ?, ?)
    ON CONFLICT(cache_key) DO UPDATE SET
      input_json = excluded.input_json,
      output_json = excluded.output_json,
      expires_at = excluded.expires_at
  `).run(cacheKey, JSON.stringify(parsed), JSON.stringify(result.output), expiresAt);

  db.prepare(`
    INSERT INTO ai_cost_logs (provider, model, input_tokens, output_tokens, estimated_cost_usd, cache_hit)
    VALUES (?, ?, ?, ?, ?, 0)
  `).run(
    result.provider,
    result.model,
    result.usage.prompt_tokens || 0,
    result.usage.completion_tokens || 0,
    0,
  );

  return { cacheHit: false, output: result.output };
}

module.exports = { getNextActions, nextActionInputSchema, nextActionOutputSchema };
