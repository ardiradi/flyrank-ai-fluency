# Internship Progress Copilot API

Backend AI Engineering capstone by Ardi Riyadi.

Public repository: https://github.com/ardiradi/flyrank-10x-solution

This project solves a real internship problem: tracking many assignments, evidence links, next actions, and reviewer-ready reports without losing the thread. It is a small backend service that turns a messy internship checklist into an API-driven progress cockpit.

## 10x claim

Finding the next assignment action and preparing reviewer evidence can take 20-30 minutes of rereading portal pages. This API reduces that to one request that returns a scoped plan, saved evidence, and a generated report.

## Concepts implemented

| Concept | Where it lives |
| --- | --- |
| API endpoints | `src/app.js` exposes auth, tasks, assignments, AI planning, jobs, and reporting routes; `/docs` serves Swagger UI from `src/openapi.js`. |
| Database | `src/db.js` uses SQLite through `node:sqlite`; data survives restarts in `data/app.db`. |
| Authentication | `src/middleware.js` verifies JWTs; `/protected/profile`, `/tasks`, AI, jobs, and reports are protected. |
| Background jobs | `src/services/jobs.js` accepts report work with HTTP 202, retries failed jobs, and lets clients poll status. |
| Reporting | `src/services/reporter.js` generates a PDF progress report. |
| Caching logic | `src/services/aiPlanner.js` caches identical AI planning requests for 10 minutes. |
| LLM integration | `src/services/aiPlanner.js` supports OpenAI-compatible chat completions with schema validation and cost logs. Local demo mode keeps the project runnable with no credit card. |
| Rate limiting / quotas | `src/middleware.js` enforces per-route request limits and returns honest 429 responses. |
| Observability | `src/metrics.js` exposes Prometheus process metrics plus low-cardinality HTTP request counts, latency histograms, and error counts at `/metrics`. |
| Containerized stack | `Dockerfile` and `docker-compose.yml` start the API with persistent volumes. |
| Test suite | `test/app.test.js` covers health, auth, CRUD, AI cache, and background PDF jobs. |

## Requirements

- Node.js 24+
- npm
- Optional: Docker Desktop
- Optional: an OpenAI-compatible API key. The app runs without one in local demo mode.

## Quick start

```bash
npm install
cp .env.example .env
npm run seed
npm start
```

Open:

```text
http://localhost:3000/health
http://localhost:3000/docs
http://localhost:3000/metrics
```

Run tests:

```bash
npm test
```

Run with Docker:

```bash
docker compose up --build
```

## Demo path

1. Sign up:

```bash
curl -i -X POST http://localhost:3000/auth/signup \
  -H "Content-Type: application/json" \
  -d "{\"email\":\"demo@example.test\",\"password\":\"strong-password\",\"fullName\":\"Demo User\"}"
```

2. Copy the returned token, then list seeded assignments:

```bash
curl -i http://localhost:3000/assignments
```

3. Create a protected task:

```bash
curl -i -X POST http://localhost:3000/tasks \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer YOUR_TOKEN" \
  -d "{\"title\":\"Publish public GitHub repo\",\"priority\":1}"
```

4. Ask for next actions:

```bash
curl -i -X POST http://localhost:3000/ai/next-actions \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer YOUR_TOKEN" \
  -d "{\"goal\":\"Finish Backend AI Engineering certificate\",\"constraints\":[\"free tools only\"],\"assignmentIds\":[\"BE-01\",\"BE-02\",\"BE-06\",\"BE-08\"]}"
```

Repeat the same request to see `cacheHit: true`.

5. Generate a report in the background:

```bash
curl -i -X POST http://localhost:3000/reports/progress \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer YOUR_TOKEN" \
  -H "Idempotency-Key: demo-report-1" \
  -d "{\"title\":\"Backend AI Engineering Progress Report\"}"
```

Poll the returned job:

```bash
curl -i http://localhost:3000/jobs/JOB_ID \
  -H "Authorization: Bearer YOUR_TOKEN"
```

6. Inspect operational metrics:

```bash
curl -s http://localhost:3000/metrics | grep internship_progress_copilot_http
```

The HTTP labels use route templates such as `/tasks/:id`, never raw IDs or query strings, to avoid unbounded metric cardinality. The endpoint is public for this local demo; a deployed version should restrict it at the network or reverse-proxy layer.

## Observability

`GET /metrics` uses the Prometheus text exposition format and reports:

- `internship_progress_copilot_http_requests_total` by method, route, and status code.
- `internship_progress_copilot_http_request_duration_seconds` as a histogram.
- `internship_progress_copilot_http_errors_total` for 4xx and 5xx responses.
- Runtime metrics for the Node.js process, prefixed with `internship_progress_copilot_`.

The test suite exercises both a successful request and an authentication error, then verifies that the scrape contains request, latency, and error series.

## API map

- `GET /` - API description.
- `GET /docs` - Swagger UI for visual API exploration.
- `GET /health` - service health check.
- `GET /metrics` - Prometheus request, latency, error, and Node.js process metrics.
- `GET /public/info` - public route for auth contrast.
- `POST /auth/signup` - create user and token.
- `POST /auth/login` - login and token.
- `POST /auth/logout` - client-side logout pattern.
- `GET /protected/profile` - protected profile proof.
- `GET /tasks` - list protected tasks.
- `POST /tasks` - create task.
- `GET /tasks/:id` - read one task.
- `PUT /tasks/:id` - update task.
- `DELETE /tasks/:id` - delete task.
- `GET /assignments` - list seeded Backend AI Engineering assignments.
- `GET /assignments/:id` - assignment detail with evidence.
- `POST /assignments/:id/evidence` - attach a repo/document/demo link and mark assignment submitted locally.
- `POST /ai/next-actions` - AI planning endpoint with schema validation, cache, and cost log.
- `POST /reports/progress` - enqueue a PDF report job and return 202.
- `GET /jobs/:id` - poll job status.
- `GET /metrics/costs` - recent AI usage and cache events.

## Data and secrets

- `.env`, local SQLite files, and generated reports are gitignored.
- Demo users use `.example.test` addresses.
- No real personal data is required for the demo.

## Non-goal

This is not a replacement for the FlyRank portal and it does not submit assignments automatically. It prepares reviewer-ready evidence and keeps the backend work organized.

## Future ideas

- Add a small frontend dashboard.
- Deploy to a free hosting tier.
- Add GitHub webhook ingestion for commit activity.
- Add RAG over local assignment briefs.
