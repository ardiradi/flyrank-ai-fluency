The README explains the project clearly and gives reviewers a useful demo path. Its main weakness is that some claims go beyond what the supplied code and verification establish.

I would prioritize these changes:

1. **Qualify the “10x” claim.** The 20–30 minute baseline and tenfold improvement have not been measured. Present them as a hypothesis, then describe a repeatable comparison: the same assignment-planning and evidence-preparation task, completed manually and through the API, with timings and output quality recorded.

2. **Correct the “one request” description.** The documented workflow uses separate requests for planning, evidence attachment, report creation, and job polling. Replace that sentence with: “The API provides next-action planning, evidence tracking, and background PDF reports through a small set of endpoints.”

3. **Explain what the planner actually sees.** The supplied planner sends the goal, constraints, and assignment IDs to the provider. It does not fetch assignment descriptions, completion status, or saved evidence. Avoid implying that its recommendations reflect the user's current progress. State that local demo mode returns deterministic sample actions; its action selection does not adapt to the supplied constraints.

4. **Distinguish usage logging from cost calculation.** The code records token usage or estimates, but stores `estimated_cost_usd` as zero. Describe this as usage and cache logging, with cost calculation pending, unless pricing-based estimates are implemented.

5. **Add a short limitations paragraph for background jobs.** The worker runs inside the API process. Retries are implemented, but the supplied code does not show recovery for jobs left `running` after a crash or exclusive claiming across overlapping workers. Document the intended single-process demo setup and avoid implying production queue reliability.

6. **Include the verification result and its scope.** The recorded run on 8 October 2026 passed all six tests, covering health, metrics, authentication, task persistence, AI validation/cache/logging, and PDF generation. Explicitly say these tests use the deterministic AI demo and do not verify a real provider or the productivity claim.

For usability, label the setup commands as Bash examples and add PowerShell equivalents, explain why Node.js 24+ is required, and show a sample planning response and completed job response. The existing non-goal and secrets sections are useful and should remain.
