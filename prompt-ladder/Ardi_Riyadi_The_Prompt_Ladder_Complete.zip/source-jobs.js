const path = require("node:path");
const { generateProgressReport } = require("./reporter");

function enqueueJob(db, { type, payload, idempotencyKey, runAt = new Date(), maxAttempts = 3 }) {
  if (idempotencyKey) {
    const existing = db.prepare("SELECT * FROM jobs WHERE idempotency_key = ?").get(idempotencyKey);
    if (existing) return existing;
  }

  const result = db.prepare(`
    INSERT INTO jobs (type, payload_json, idempotency_key, run_at, max_attempts)
    VALUES (?, ?, ?, ?, ?)
  `).run(type, JSON.stringify(payload), idempotencyKey || null, runAt.toISOString(), maxAttempts);

  return db.prepare("SELECT * FROM jobs WHERE id = ?").get(Number(result.lastInsertRowid));
}

async function processDueJobs(db, config, limit = 5) {
  const jobs = db.prepare(`
    SELECT * FROM jobs
    WHERE status IN ('queued', 'retry') AND run_at <= ?
    ORDER BY id ASC
    LIMIT ?
  `).all(new Date().toISOString(), limit);

  const results = [];

  for (const job of jobs) {
    db.prepare(`
      UPDATE jobs SET status = 'running', attempts = attempts + 1, updated_at = CURRENT_TIMESTAMP
      WHERE id = ?
    `).run(job.id);

    try {
      const payload = JSON.parse(job.payload_json || "{}");
      let result;
      if (job.type === "progress_report") {
        result = await generateProgressReport({
          db,
          userId: payload.userId,
          outputDir: path.join(config.rootDir, "artifacts", "reports"),
          title: payload.title || "Internship Progress Report",
        });
      } else {
        throw new Error(`Unknown job type: ${job.type}`);
      }

      db.prepare(`
        UPDATE jobs SET status = 'complete', result_json = ?, error = NULL, updated_at = CURRENT_TIMESTAMP
        WHERE id = ?
      `).run(JSON.stringify(result), job.id);
      results.push({ id: job.id, status: "complete", result });
    } catch (error) {
      const attempts = job.attempts + 1;
      const nextStatus = attempts >= job.max_attempts ? "failed" : "retry";
      const delayMs = Math.min(60_000, 1000 * 2 ** attempts);
      const nextRun = new Date(Date.now() + delayMs).toISOString();
      db.prepare(`
        UPDATE jobs
        SET status = ?, error = ?, run_at = ?, updated_at = CURRENT_TIMESTAMP
        WHERE id = ?
      `).run(nextStatus, String(error.message || error), nextRun, job.id);
      results.push({ id: job.id, status: nextStatus, error: String(error.message || error) });
    }
  }

  return results;
}

function startWorker(db, config) {
  const timer = setInterval(() => {
    processDueJobs(db, config).catch((error) => {
      console.error("worker error", error);
    });
  }, 2500);
  timer.unref();
  return timer;
}

module.exports = { enqueueJob, processDueJobs, startWorker };
